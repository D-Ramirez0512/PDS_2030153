﻿# Repositorio de Brandon Muñoz (2030069)

Este repositorio contiene actividades desarrolladas como parte del curso. Cada actividad se encuentra organizada por unidad y número de actividad.

## Cómo usar

Ejecutar el archivo `main.py` introduciendo un comando especificando la unidad y actividad de la siguiente manera:
- `python main.py u1act1`
donde u1 pertenece a la unidad y act1 al número de la tarea


